# COMP 182 - Algorithmic Thinking
This is a collection of programming assignments that I have had to do for my COMP 182 - Algorithmic Thinking course
* Graph Resilience - Involved writing a program which calculated the size of the largest connected component on a graph as well as simulating targeted and random network attacks to estimate network resilience
