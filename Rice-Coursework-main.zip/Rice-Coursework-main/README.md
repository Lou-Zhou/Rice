# Courses
This is a collection of programming work from courses throughout my time at Rice University
## Fall 2023
* [COMP 140 - Computational Thinking](https://courses.rice.edu/courses/!SWKSCAT.cat?p_action=CATALIST&p_acyr_code=2024&p_crse_numb=140&p_subj=COMP)
## Spring 2024
* [SMGT 430 - Introduction to Sport Analytics](https://courses.rice.edu/courses/!SWKSCAT.cat?p_action=CATALIST&p_acyr_code=2024&p_crse_numb=430&p_subj=SMGT)
* [COMP 182 - Algorithmic Thinking](https://courses.rice.edu/courses/!SWKSCAT.cat?p_action=CATALIST&p_acyr_code=2024&p_crse_numb=182&p_subj=COMP)


